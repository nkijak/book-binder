def main() {
  return "hello world"
}

console.log(main())
