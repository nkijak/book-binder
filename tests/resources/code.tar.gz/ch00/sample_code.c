// tag::program[]
#define BARGRAPH 5

#define PWM_MIN 0
#define PWM_MAX 255
#define DELAY   5

// tag::sample-code[]
void setup() {
  pinMode(BARGRAPH, OUTPUT);
}
// end::sample-code[]

void loop() {
  for (int i = PWM_MIN; i <= PWM_MAX; i++) {
    analogWrite(BARGRAPH, i);
    delay(DELAY);             // <1>
  }

  for (int i = PWM_MAX; i >= PWM_MIN; i--) {
    analogWrite(BARGRAPH, i);
    delay(DELAY);
  }
}
// end::program[]
